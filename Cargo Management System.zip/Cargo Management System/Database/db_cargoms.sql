use db_cargoms

Create Table container
(
containerID varchar(30) primary key,
containerCapcity bigint,
containerCapcityRemaining bigint,
containerDimension varchar(50),
containeCargoType varchar(50),
containerSpecification varchar(255),
containerStatus varchar(50)
)
Create Table Users
(
userID varchar(30) primary key,
userName varchar(30) unique,
userFullName varchar(50) ,
userPass varchar(30),
userDesg char,
userStatus char
)
Create  Table Freight_Rate
(
Id int identity primary key,
[From] varchar(30),
[To] varchar(30),
Distance float,
ratepkg float,
)
select * from Users
update users set userPass = '123' where userID = 'uid-004'
Create  Table Customer
(
customerID varchar(30) primary key,
customerName varchar(50),
customerMobile varchar(50),
customerCountry varchar(50),
customerAddress varchar(150),
customerStatus char
)
insert into Users values ('user-001','ahmed','Ahmed Israr','123','A','A')
UPDATE CUSTOMER SET customerAddress = 'CLIFTON, KARACHI' WHERE customerID = 'cus-001' 
insert into Customer Values ('cus-001','Ahmed Israr','03323419088','Pakistan','Clifton','A')
insert into Shipment Values ('ship-001','con-009','cus-001','Zakir Khan','023165589','China','Shenzen','Pending')

select * from view_Shipment

SELECT * FROM Customer;
SELECT * FROM Shipment;
SELECT * FROM Products;
SELECT * FROM Billing
select * from container
select * from users
SELECT distinct(containerID),customerCountry,containerCapcity,containerDimension,containeCargoType,containerSpecification,containerStatus,shipmentToCountry,shipmentDep,(containerCapcity - (select SUM(productQty) as Rem from products where shipmentID in ( select shipmentID from view_Shipment where customerCountry = 'Pakistan' and shipmentToCountry = 'China')) ) as rem FROM view_Shipment where customerCountry = 'Pakistan' and shipmentToCountry = 'China' and (containerStatus = 'Booked' or containerStatus = 'Confirmed')

INSERT INTO PRODUCTS VALUES ('','abc','avc','solid',5,5,500,1500)
TRUNCATE TABLE Container
TRUNCATE TABLE Customer
TRUNCATE TABLE Shipment
TRUNCATE TABLE Products
TRUNCATE TABLE Billing
Create  Table Shipment
(
shipmentID varchar(30) primary key,
containerID varchar(30) foreign key references Container(containerID),
customerID varchar(30) foreign key references Customer(customerID),
shipmentToName varchar(50),
shipmentToMobile varchar(50),
shipmentToCountry varchar(50),
shipmentToAddress varchar(150),
shipmentDep varchar(150),
shipmentStatus varchar(50)
)

Create  Table Products
(
productId int identity primary key,
shipmentID varchar(30) foreign key references Shipment(shipmentID),
productName varchar(50),
productCategory varchar(50),
productType varchar(20),
productQty bigint,
productWeight float,
productFR float,
productTotal float
)
Create   Table Billing
(
billingID varchar(30) primary key,
shipmentID varchar(30) foreign key references Shipment(shipmentID),
billingSubTotal float,
billingDiscount float,
billingTotal float,
billingAmountDue float,
billingAmountPaid float,
billingDate date,
billingStatus varchar(30)
)
select * from Freight_Rate
insert into Freight_Rate Values ('Pakistan','Afghanistan',0,0)
insert into Freight_Rate Values ('Pakistan','Australia',0,0)
insert into Freight_Rate Values ('Pakistan','Bangladesh',0,0)
insert into Freight_Rate Values ('Pakistan','Canada',0,0)
insert into Freight_Rate Values ('Pakistan','China',0,0)
insert into Freight_Rate Values ('Pakistan','Saudi Arabia',0,0)
insert into Freight_Rate Values ('Pakistan','UAE',0,0)
insert into Freight_Rate Values ('Pakistan','United States Of America',0,0)
insert into Freight_Rate Values ('Pakistan','united Kingdom',0,0)
insert into Users Values ('uid-001','Ahmed','Ahmed Israr','123','A','A')
insert into Users Values ('uid-002','israr','Ahmed Israr','123','E','A')
select * from Users where (userID like '%002%' or userDesg like '%002%') and userDesg <> 'A'
select * from container
insert into container values ('con-001',1000,'25x60x50','Solid','abc','Free');
insert into container values ('con-002',1000,'25x60x50','Liquid','abc','Booked');
	insert into container values ('con-003',1000,'25x60x50','Liquid','abc','Booked');
	insert into Products values ('ship-001','','','',500,0,0,0)
	
	SELECT distinct(containerID),customerCountry,containerCapcity,containerDimension,containeCargoType,containerSpecification,containerStatus,shipmentToCountry,shipmentDep,(containerCapcity - (select SUM(productQty) as Rem from products where shipmentID in ( select DISTINCT(shipmentID) from view_Shipment where customerCountry = 'Pakistan' and shipmentToCountry = 'China')) ) as rem FROM view_Shipment where customerCountry = 'Pakistan' and shipmentToCountry = 'China' and containerStatus = 'Booked'
	SELECT distinct(containerID),customerCountry,containerCapcity,containerDimension,containeCargoType,containerSpecification,containerStatus,shipmentToCountry,shipmentDep,(containerCapcity - (select SUM(productQty) as Rem from products where shipmentID in ( select shipmentID from view_Shipment where customerCountry = 'Pakistan' and shipmentToCountry = 'China')) ) as rem FROM view_Shipment where customerCountry = 'Pakistan' and shipmentToCountry = 'China' and (containerStatus = 'Free' or containerStatus = 'Confirmed')