/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Vector;

/**
 *
 * @author Ahmed Israr
 */
public class Product {
    private String Name,Category,Type;
    private double Qty,Weight,FreightRate,Total;
  DatabaseHandler con = new DatabaseHandler();
  Shipment ship = new Shipment();
    public Product() {
    }
    public Product(String Name, String Category, String Type, double Qty, double Weight, double FreightRate, double Total) {
        this.Name = Name;
        this.Category = Category;
        this.Type = Type;
        this.Qty = Qty;
        this.Weight = Weight;
        this.FreightRate = FreightRate;
        this.Total = Total;
    }
    
    
     public Vector getProductDetails(String shipmentId)
    { 
         con.Select("SELECT * FROM Products where shipmentID = '"+shipmentId+"'");
         try {
             Vector<Vector<String> > v = new Vector();
           int i=1; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(String.valueOf(i));
                v.get(i).add(con.rs.getString("productName"));
                v.get(i).add(con.rs.getString("productCategory"));
                v.get(i).add(con.rs.getString("productType"));
                v.get(i).add(con.rs.getString("productQty"));
                v.get(i).add(con.rs.getString("productWeight"));
                v.get(i).add(con.rs.getString("productFR"));
                v.get(i).add(con.rs.getString("productTotal"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
       public void AddProducts(String shipmentId) 
   {
       String query ;
            query = "insert into Products values ('"+shipmentId+"','"+Name+"','"+Category+"','"+Type+"',"+Qty+","+Weight+","+FreightRate+","+Total+")";
            con.Operation(query);
        }
   
}
