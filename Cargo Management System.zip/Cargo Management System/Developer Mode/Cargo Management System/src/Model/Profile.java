/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;



/**
 *
 * @author Ahmed Israr
 */
public class Profile {
     DatabaseHandler con = new DatabaseHandler();
     private String userId;

    public Profile(String userId) {
        this.userId = userId;
    }
     
    public void updateUserName(String Username)
    {
         String query = "update Users set userName = '"+Username+"' where userID = '"+userId+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
                
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        } 
    }

    public void updateName(String Name)
    {
         String query = "update Users set userFullName = '"+Name+"' where userID = '"+userId+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
                
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        } 
    }
     public void updatePassword(String pass)
    {
         String query = "update Users set userPass = '"+pass+"' where userID = '"+userId+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
                
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        } 
    }
    
    
}
