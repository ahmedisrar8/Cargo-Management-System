package Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ahmed Israr
 */
import java.sql.*;

public class DatabaseHandler {

    public ResultSet rs;
    Connection con;
    Statement stmt;
    private String dbURL = "jdbc:sqlserver://localhost:64703;databaseName=db_cargoms;";
    private String user = "sa";
    private String pass = "123";

    public void Select(String query) {
        try {
            con = DriverManager.getConnection(dbURL, user, pass);
            stmt = con.createStatement();
            rs = stmt.executeQuery(query);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }


    public void Operation(String query) {
        try {
            con = DriverManager.getConnection(dbURL, user, pass);
            stmt = con.createStatement();
            stmt.executeQuery(query);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

}
