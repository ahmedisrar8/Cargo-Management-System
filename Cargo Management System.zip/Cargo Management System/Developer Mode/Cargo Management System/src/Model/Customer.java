/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Vector;


/**
 *
 * @author Ahmed Israr
 */
public class Customer {
    private String customerId,customerName,customerMobile,customerAdd;
    DatabaseHandler con = new DatabaseHandler();
    public Customer() {
        
    }

    public Customer(String customerName, String customerMobile, String customerAdd) {
        this.customerName = customerName;
        this.customerMobile = customerMobile;
        this.customerAdd = customerAdd;
    }
    public void setCustomerId(String customerId)
    {
        this.customerId = customerId;
    }
    public void updateCustomerDetails()
    {
      String query = "UPDATE Customer SET  customerName =  '"+customerName+"' , customerMobile = '"+customerMobile+"' , customerAddress = '"+customerAdd+"' WHERE customerID = '"+customerId+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }   
    }
    public Vector getCustomerDetails()
    { 
         con.Select("SELECT * FROM Customer");
         try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("customerID"));
                v.get(i).add(con.rs.getString("customerName"));
                v.get(i).add(con.rs.getString("customerMobile"));
                v.get(i).add(con.rs.getString("customerCountry"));
                v.get(i).add(con.rs.getString("customerAddress"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    public Vector  getCustomerDetails(String Parameter)
    {
         con.Select("SELECT * FROM Customer where customerID like '%"+Parameter+"%' or customerName like '%"+Parameter+"%' or customerMobile like '%"+Parameter+"%' or customerAddress like '%"+Parameter+"%'");
        try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("customerID"));
                v.get(i).add(con.rs.getString("customerName"));
                v.get(i).add(con.rs.getString("customerMobile"));
                v.get(i).add(con.rs.getString("customerCountry"));
                v.get(i).add(con.rs.getString("customerAddress"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    private void CusIdGenerator()
    {
              con.Select("SELECT  COUNT(customerID)+1 as ID FROM Customer");
         try {  
            if(con.rs.next())
            {
                customerId =  "cus-00"+con.rs.getString("ID");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    public void CreateCustomer()
   {
       CusIdGenerator();
       String query = "insert into Customer Values ('"+customerId+"','"+customerName+"','"+customerMobile+"','Pakistan','"+customerAdd+"','A')";
       con.Operation(query);
   }
    public String GetCustomerId()
    {
        return customerId;
    }
    
}
