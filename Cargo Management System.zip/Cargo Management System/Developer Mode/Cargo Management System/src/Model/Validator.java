/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.regex.*;

/**
 *
 * @author Ahmed Israr
 */
public class Validator {
    
    public boolean validateAlphabets(String Input)
    {
        Pattern pattern= Pattern.compile("^[A-Za-z ]+$");
       if(pattern.matcher(Input).matches())
           return true;
       else
           return false;
    }
    public boolean validateUsername(String Input)
    {
        Pattern pattern= Pattern.compile("^[A-Za-z0-9_-]{3,15}$");
       if(pattern.matcher(Input).matches())
           return true;
       else
           return false;
    }
    public boolean validateNumbers(String Input)
    {
        Pattern pattern= Pattern.compile("^\\d+$");
       if(pattern.matcher(Input).matches())
           return true;
       else
           return false;
    }
    public boolean validateDouble(String Input)
    {
        Pattern pattern= Pattern.compile("^([0-9]*|\\d*\\.\\d{1}?\\d*)$");
       if(pattern.matcher(Input).matches())
           return true;
       else
           return false;
    }
    public boolean validateMobile(String Input)
    {
        Pattern pattern= Pattern.compile("^[+]\\d+$");
       if(pattern.matcher(Input).matches())
           return true;
       else
           return false;
    }
}
