/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.io.*;
import java.util.Vector;
/**
 *
 * @author Ahmed Israr
 */
public class Billing {
    private String billId,shipmentId,billStatus;
    private double billSubTotal,billDiscount,billTotal,billDue,billPaid;
    DatabaseHandler con = new DatabaseHandler();
    public Billing() {
    }

    public Billing(String shipmentId, double billSubTotal, double billDiscount, double billTotal, double billDue, double billPaid, String billStatus) {
        this.shipmentId = shipmentId;
        this.billSubTotal = billSubTotal;
        this.billDiscount = billDiscount;
        this.billTotal = billTotal;
        this.billDue = billDue;
        this.billPaid = billPaid;
        this.billStatus = billStatus;
    }
    
    
     public void GenerateBill()
   {
       BillIdGenerator();
       String query = "insert into Billing values ('"+billId+"','"+shipmentId+"','"+billSubTotal+"','"+billDiscount+"','"+billTotal+"','"+billDue+"','"+billPaid+"',getdate(),'"+billStatus+"')";
        con.Operation(query);
         ReceiptGenerator();
   }
     private void BillIdGenerator()
    {
              con.Select("SELECT  COUNT(billingID)+1 as ID FROM Billing");
         try {  
            if(con.rs.next())
            {
                billId =  "Bill-00"+con.rs.getString("ID");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
     public Vector getBillingDetails(String parameter)
    { 
         con.Select("SELECT * FROM Billing where shipmentID like '%"+parameter+"%' or billingID like '%"+parameter+"%' ");
         try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("billingID"));
                v.get(i).add(con.rs.getString("shipmentID"));
                v.get(i).add(con.rs.getString("billingSubTotal"));
                v.get(i).add(con.rs.getString("billingDiscount")+"%");
                v.get(i).add(con.rs.getString("billingTotal"));
                v.get(i).add(con.rs.getString("billingDate"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
      public Vector getBillingDetails()
    { 
         con.Select("SELECT * FROM Billing");
         try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("billingID"));
                v.get(i).add(con.rs.getString("shipmentID"));
                v.get(i).add(con.rs.getString("billingSubTotal"));
                v.get(i).add(con.rs.getString("billingDiscount")+"%");
                v.get(i).add(con.rs.getString("billingTotal"));
                v.get(i).add(con.rs.getString("billingDate"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
     public void ReceiptGenerator()
     {
         Shipment ship = new Shipment(shipmentId);
        Vector<Vector<String>> vship = ship.getShipmentDetails(shipmentId);
        Customer cus = new Customer();
        Vector<Vector<String>> vcus = cus.getCustomerDetails(ship.getCustomerId());
        Vector<Vector<String>> vbill = getBillingDetails(shipmentId);
        try
        {
            
            PrintWriter outFile= new PrintWriter(billId+".txt");
 
            
            for(int i=1; i<=200;i++)
            outFile.print("-");
            outFile.println("");
            outFile.println("\t\t\t\t CARGO INTERNATIONAL");
            for(int i=1; i<=200;i++)
            outFile.print("-");
            outFile.println("");
            outFile.println(billId+"\t\t\t\t\t\t\t\t\t\t"+vbill.get(0).get(5));
            for(int i=1; i<=200;i++)
            outFile.print("-");
            outFile.println("");
            outFile.println("From:\t\t\t\t\t\t\t\tTo:");
            outFile.println(vcus.get(0).get(1)+"\t\t\t\t\t\t\t"+vship.get(0).get(1));
            outFile.println(vcus.get(0).get(2)+"\t\t\t\t\t\t\t"+vship.get(0).get(2));
            outFile.println(vcus.get(0).get(3)+"\t\t\t\t\t\t\t"+vship.get(0).get(3));
            outFile.println(vcus.get(0).get(4)+"\t\t\t\t\t\t"+vship.get(0).get(4));
            for(int i=1; i<=200;i++)
            outFile.print("-");
            outFile.println("");
            outFile.println("Sno\tName\t\t\tCategory\t\tQty\tWeight\t\tRate(RS)\tTotal(RS)");
            for(int i=1; i<=200;i++)
            outFile.print("-");
            outFile.println("");
             Product container = new Product();
            Vector<Vector<String>> rs = container.getProductDetails(shipmentId);
            int count = 1;
            for (int i = 0; i < rs.size() - 1; i++) {
              outFile.println(count+"\t"+rs.get(i).get(0)+"\t"+rs.get(i).get(1)+"\t\t"+rs.get(i).get(2)+"\t"+rs.get(i).get(3)+"\t\t"+rs.get(i).get(4)+"\t\t"+rs.get(i).get(5));
              count++;
            }
            for(int i=1; i<=200;i++)
            outFile.print("-");
            outFile.println("");
            outFile.println("\t\t\t\t\t\t\t\t\t\t\t\tSub Total:Rs. "+vbill.get(0).get(2));
             outFile.println("\t\t\t\t\t\t\t\t\t\t\t\tDiscount :"+vbill.get(0).get(3));
              outFile.println("\t\t\t\t\t\t\t\t\t\t\t\tTotal    :Rs. "+vbill.get(0).get(4));
            outFile.close();
        }
        catch(FileNotFoundException e)
        {
            System.out.println(e.getMessage());
        }
     }
}
