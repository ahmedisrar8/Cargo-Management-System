/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import View_Controller.Freight_Rate;
import java.sql.SQLException;
import java.util.Vector;

/**
 *
 * @author Ahmed Israr
 */
public class Freight  {
    DatabaseHandler con = new DatabaseHandler();
    private String From,To,Distance,Rate_pkg;
    
    public Freight(){
    }
    public Freight(String From,String To,String Distance,String Rate_pkg)
    {
        this.From = From;
        this.To = To;
        this.Distance = Distance;
        this.Rate_pkg = Rate_pkg;
    }
    public Vector getFreight_Rates()
    {
        con.Select("SELECT * FROM Freight_Rate");
         try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("Id"));
                v.get(i).add(con.rs.getString("From"));
                v.get(i).add(con.rs.getString("To"));
                v.get(i).add(con.rs.getString("Distance"));
                v.get(i).add(con.rs.getString("ratepkg"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (SQLException ex) {
            ex.printStackTrace();
             System.out.println("Model.Freight_RateModel.getFreight_Rates()"+ex);
            return null;
        }
    }
     public Vector getFreight_Rates(String q)
    {
        con.Select("SELECT * FROM Freight_Rate Where Id like '%"+q+"%' or [To] like '%"+q+"%' ");
         try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("Id"));
                v.get(i).add(con.rs.getString("From"));
                v.get(i).add(con.rs.getString("To"));
                v.get(i).add(con.rs.getString("Distance"));
                v.get(i).add(con.rs.getString("ratepkg"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
     public double getFreightRate(String o,String d)
     {
         con.Select("SELECT * FROM Freight_Rate WHERE [From] = '"+o+"' and [To] = '"+d+"'");
         try {
            double Ratepkg = 0.0;
           
            if (con.rs.next()) {
                 Ratepkg = Double.parseDouble(con.rs.getString("ratepkg"));
                            } 
            return Ratepkg;
        } catch (SQLException ex) {
            ex.printStackTrace();
             System.out.println("Model.Freight_RateModel.getFreight_Rates()"+ex);
            return 0.0;
        }
     }
     public void UpdateFreight_Rate()
     {
            String query = "UPDATE Freight_rate SET [From] = '"+From+"' , [To] = '"+To+"' , Distance = "+Distance+",  ratepkg = '"+Rate_pkg+"' WHERE [To] = '"+To+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
     }
}
