/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.text.SimpleDateFormat;
import java.util.Vector;
import java.util.Date;

/**
 *
 * @author Ahmed Israr
 */
public class Users{

    private String userId, userName, userfullName, userPass, userDesg, userStatus;
    DatabaseHandler con = new DatabaseHandler();

    public Users(String userId, String userName, String userfullName, String userDesg) {
         Date date = new Date();
         SimpleDateFormat ft = 
         new SimpleDateFormat("s-S-H-y");
        this.userId = userId;
        this.userName = userName;
        this.userfullName = userfullName;
        this.userDesg = userDesg;
        this.userStatus = "A";
        this.userPass = userId+"-"+ft.format(date);
        this.userStatus = "A";
       
    }
    
    public Users() {
         
         System.out.println();
    }
   
    public Vector getUserDetails() {
        con.Select("SELECT * FROM Users where userDesg <> 'A'");
        try {
            Vector<Vector<String>> v = new Vector();
            int i = 0;
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("userID"));
                v.get(i).add(con.rs.getString("userFullName"));
                v.get(i).add(con.rs.getString("userName"));
                v.get(i).add(con.rs.getString("userPass"));
                if (con.rs.getString("userDesg").equals("S")) {
                    v.get(i).add("Sub Admin");
                } else {
                    v.get(i).add("Employee");
                }
                if (con.rs.getString("userStatus").equals("A")) {
                    v.get(i).add("Active");
                    
                } else {
                    v.get(i).add("Deactive");
                }
                v.add(new Vector());
                i++;
            }
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public Vector getUserDetails(String Parameter) {
        con.Select("SELECT * FROM Users where (userId like '%" + Parameter + "%' or userName like '%" + Parameter + "%' or userFullName like '%" + Parameter + "%' or userDesg like '%" + Parameter + "%'  or userStatus like '%" + Parameter + "%') and userDesg <> 'A' ");
        try {
            Vector<Vector<String>> v = new Vector();
            int i = 0;
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("userID"));
                v.get(i).add(con.rs.getString("userFullName"));
                v.get(i).add(con.rs.getString("userName"));
                v.get(i).add(con.rs.getString("userPass"));
                if (con.rs.getString("userDesg").equals("S")) {
                    v.get(i).add("Sub Admin");
                } else {
                    v.get(i).add("Employee");
                }
                if (con.rs.getString("userStatus").equals("A")) {
                    v.get(i).add("Active");
                    
                } else {
                    v.get(i).add("Deactive");
                }
                v.add(new Vector());
                i++;
            }
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public String IdGenerator() {
        con.Select("SELECT  COUNT(userID)+1 as ID FROM Users");
        try {
            if (con.rs.next()) {
                return "uid-00" + con.rs.getString("ID");
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    public boolean UserNameMatcher(String q)
    {
        con.Select("SELECT  userName FROM Users where userName = '"+q+"'");
        try {
            if (con.rs.next()) {
                return true;
            }
            else
            {
                return false;
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
    public void AddUsers()
    {
        String query = "INSERT INTO Users VALUES('"+userId+"','"+userName+"','"+userfullName+"','"+userPass+"','"+userDesg+"','"+userStatus+"')"; 
        con.Operation(query);
    }
    public void DeactivateUser(String userId, String userStatus)
    {
        String query = "UPDATE Users SET userStatus = '"+userStatus+"' WHERE userID = '"+userId+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    public void UpdateUserDetails(String userId,String userName,String userFullName , String userDesg)
    {
          String query = "UPDATE Users SET userID = '"+userId+"' , userName = '"+userName+"' , userFullName = '"+userFullName+"' , userDesg = '"+userDesg+"' WHERE userID = '"+userId+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    public Vector GetUserDetails(String userId)
    {
        Vector<String> v = new Vector<>();
        con.Select("SELECT  * FROM Users where userID = '"+userId+"'");
        try {
            if (con.rs.next()) {
                v.add(con.rs.getString("userId"));
                v.add(con.rs.getString("userName"));
                v.add(con.rs.getString("userFullName"));
                v.add(con.rs.getString("userDesg"));
                return v;
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
