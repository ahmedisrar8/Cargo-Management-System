package Model;

import java.sql.SQLException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ahmed Israr
 */
public class Login {
    private String fullName;
    private String uname;
    private String pass;
    private String userDesg;
    private String userId;
    public Login(String uname, String pass)
    {
        this.uname = uname;
        this.pass = pass;
    }

   
    
    public boolean Auth()
    {
        DatabaseHandler con = new DatabaseHandler();
        con.Select("select * from users where userName = '" +uname + "' and userPass = '" + pass + "' and userStatus = 'A' ");
        try {
           
            if (con.rs.next()) {
                fullName = con.rs.getString("userFullName");
                userDesg = con.rs.getString("userDesg");
                userId =  con.rs.getString("userID");
                return true;
            } else {
                return false;
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
             return false;
        }
    
    }
    public String getName()
    {
        return fullName;
    }
     public String getUserName()
    {
        return uname;
    }
    public void setName(String fullName)
    {
        this.fullName =  fullName;
    }
    public void setUserName(String UserName)
    {
        this.uname =  UserName;
    }
    public String getUserId()
    {
        return userId;
    }
    public String getDesg()
    {
        return userDesg;
    }
}
