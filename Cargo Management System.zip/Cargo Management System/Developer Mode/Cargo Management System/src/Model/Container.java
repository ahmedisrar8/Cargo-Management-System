package Model;

import java.util.Vector;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ahmed Israr
 */
public class Container  {
    private String containerID,containerDimensions,containerType,containerSpecification;
    private String containerCapacity;
    DatabaseHandler con = new DatabaseHandler();

    public Container(String containerID)
    {
        this.containerID = containerID;
    }
    public Container(String containerID,String containerCapacity,String containerDimensions,String containerType,String containerSpecification) {
        this.containerID = containerID;
        this.containerCapacity = containerCapacity;
        this.containerDimensions = containerDimensions;
        this.containerType = containerType;
        this.containerSpecification = containerSpecification;
    }
    public Container(){
       
    }
    public void AddContainer()
    {
        String query = "INSERT INTO Container VALUES('"+containerID+"',"+containerCapacity+","+containerCapacity+",'"+containerDimensions+"','"+containerType+"','"+containerSpecification+"','Free')"; 
        con.Operation(query);
    }
    public Vector getContainerDetails()
    { 
         con.Select("SELECT * FROM Container");
         try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("containerID"));
                v.get(i).add(con.rs.getString("containerCapcity"));
                v.get(i).add(con.rs.getString("containerDimension"));
                v.get(i).add(con.rs.getString("containeCargoType"));
                v.get(i).add(con.rs.getString("containerSpecification"));
                v.get(i).add(con.rs.getString("containerStatus"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    public Vector  getContainerDetails(String Parameter)
    {
         con.Select("SELECT * FROM Container where containerId like '%"+Parameter+"%' or containeCargoType like '%"+Parameter+"%' or containerCapcity like '%"+Parameter+"%' or containerStatus like '%"+Parameter+"%' or containerDimension like '%"+Parameter+"%'");
        try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("containerID"));
                v.get(i).add(con.rs.getString("containerCapcity"));
                v.get(i).add(con.rs.getString("containerDimension"));
                v.get(i).add(con.rs.getString("containeCargoType"));
                v.get(i).add(con.rs.getString("containerSpecification"));
                v.get(i).add(con.rs.getString("containerStatus"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    public String IdGenerator()
    {
              con.Select("SELECT  COUNT(containerID)+1 as ID FROM Container");
         try {  
            if(con.rs.next())
            {
                return "con-00"+con.rs.getString("ID");
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
    
    public void UpdateContainerDetails(String containerId,String containerCapcity, String containerDimensions,String cargoType,String otherSpec){
         String query = "UPDATE Container SET  containerCapcity = '"+containerCapcity+"' , containerDimension = '"+containerDimensions+"' , containeCargoType = '"+cargoType+"' , containerSpecification = '"+otherSpec+"' WHERE containerID = '"+containerId+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    public void UpdateContainerStatus(String Status)
    {
       String query = "update Container set containerStatus = '"+Status+"' where containerID = '"+containerID+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        } 
    }
    public void UpdateContainerCapcity(float Capcity)
    {
       String query = "update Container set containerCapcityRemaining =containerCapcityRemaining - "+Capcity+" where containerID = '"+containerID+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        } 
    }
    public Vector GetContainerDetails(String containerId)
    {
        Vector<String> v = new Vector<>();
        con.Select("SELECT  * FROM container where containerID = '"+containerId+"'");
        try {
            if (con.rs.next()) {
                v.add(con.rs.getString("containerID"));
                v.add(con.rs.getString("containerCapcity"));
                v.add(con.rs.getString("containerDimension"));
                v.add(con.rs.getString("containeCargoType"));
                v.add(con.rs.getString("containerSpecification"));
                return v;
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
