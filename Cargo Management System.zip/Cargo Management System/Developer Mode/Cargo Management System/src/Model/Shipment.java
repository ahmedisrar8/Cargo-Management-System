/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;

/**
 *
 * @author Ahmed Israr
 */
public class Shipment {
    private String containerID,ShipmentId,CustomerID,Status,Origin;
    private String cosigneeName, cosigneeMobile, Destination, cosingneeAddress,Deptdate;
    private double subTotal,Discount,Total;
    private double RatePerKg;
    private Product[] product ;
 DatabaseHandler con = new DatabaseHandler();

    public Shipment() {
    }
 
    public Shipment(String ShipmentId ) {
        this.ShipmentId = ShipmentId;
    }
   
    public Shipment(String containerID, String CustomerID, String cosigneeName, String cosigneeMobile, String Destination, String cosingneeAddress, String Deptdate,String Status, double RatePerKg, Product[] product) {
        this.containerID = containerID;
        this.CustomerID = CustomerID;
        this.cosigneeName = cosigneeName;
        this.cosigneeMobile = cosigneeMobile;
        this.Destination = Destination;
        this.cosingneeAddress = cosingneeAddress;
        this.Deptdate = Deptdate;
        this.Status = Status;
        this.RatePerKg = RatePerKg;
        this.product = product;
    }

    
 public String getCustomerId()
    {
           con.Select("SELECT customerID from customer where customerID In (Select customerID from Shipment where ShipmentID = '"+ShipmentId+"')");
         try {  
            if(con.rs.next())
            {
                return con.rs.getString("customerID");
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
  public String getContainerId()
    {
           con.Select("SELECT containerID from container where containerID In (Select containerID from Shipment where ShipmentID = '"+ShipmentId+"')");
         try {  
            if(con.rs.next())
            {
                return con.rs.getString("containerID");
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }
   
    
   public void SetOriginDestination(String Origin, String Destination)
   {
       this.Origin = Origin;
       this.Destination = Destination;
       GetFrieghtRate();
   }
    private void GetFrieghtRate()
    {
        Freight rate = new Freight();
        this.RatePerKg = rate.getFreightRate(Origin, Destination);
    }
    public double GetRatePKg()
    {
        return RatePerKg;
    }
   public Vector getContainerDetails(String To)
    { 
         con.Select("SELECT distinct(containerID),customerCountry,containerCapcity,containerDimension,containeCargoType,containerSpecification,containerStatus,shipmentToCountry,shipmentDep,containerCapcityRemaining   FROM view_Shipment where customerCountry = 'Pakistan' and shipmentToCountry = '"+To+"' and (containerStatus = 'Booked' or containerStatus = 'Confirmed')");
         try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("containerID"));
                 v.get(i).add(con.rs.getString("shipmentDep"));
                v.get(i).add(con.rs.getString("containerCapcity"));
                v.get(i).add(con.rs.getString("containerCapcityRemaining"));
                v.get(i).add(con.rs.getString("containerDimension"));
                v.get(i).add(con.rs.getString("containeCargoType"));
                v.get(i).add(con.rs.getString("containerSpecification"));
                v.get(i).add(con.rs.getString("containerStatus"));
                v.add(new Vector());
                i++;
            } 
            
               DatabaseHandler con1 = new DatabaseHandler();
                 con1.Select("Select * from Container where containerStatus = 'free'");
                 
                  while (con1.rs.next()) {
                v.get(i).add(con1.rs.getString("containerID"));
                v.get(i).add("Not Decided");
                v.get(i).add(con1.rs.getString("containerCapcity"));
                v.get(i).add(con1.rs.getString("containerCapcity"));
                v.get(i).add(con1.rs.getString("containerDimension"));
                v.get(i).add(con1.rs.getString("containeCargoType"));
                v.get(i).add(con1.rs.getString("containerSpecification"));
                v.get(i).add(con1.rs.getString("containerStatus"));
                v.add(new Vector());
                i++;
                
            
            
            }
            return v;
        } catch (Exception ex) {
             System.out.println("Model.ShipmentModel.getContainerDetails()"+ex);
            return null;
        }
    }
   
   public Vector getShipmentDetails()
   {
       con.Select("SELECT * FROM Shipment");
         try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("shipmentID"));
                v.get(i).add(con.rs.getString("shipmentToName"));
                v.get(i).add(con.rs.getString("shipmentToMobile"));
                v.get(i).add(con.rs.getString("shipmentToCountry"));
                v.get(i).add(con.rs.getString("shipmentToAddress"));
                v.get(i).add(con.rs.getString("shipmentDep"));
                v.get(i).add(con.rs.getString("shipmentStatus"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
   }
    public Vector getShipmentDetails(String Parameter)
   {
       con.Select("SELECT * FROM Shipment where shipmentID like '%"+Parameter+"%' or shipmentToName like '%"+Parameter+"%' or shipmentToMobile like '%"+Parameter+"%' or shipmentToCountry like '%"+Parameter+"%' or shipmentDep like '%"+Parameter+"%' or shipmentStatus like '%"+Parameter+"%'");
         try {
             Vector<Vector<String> > v = new Vector();
           int i=0; 
            v.add(new Vector());
            while (con.rs.next()) {
                v.get(i).add(con.rs.getString("shipmentID"));
                v.get(i).add(con.rs.getString("shipmentToName"));
                v.get(i).add(con.rs.getString("shipmentToMobile"));
                v.get(i).add(con.rs.getString("shipmentToCountry"));
                v.get(i).add(con.rs.getString("shipmentToAddress"));
                v.get(i).add(con.rs.getString("shipmentDep"));
                v.get(i).add(con.rs.getString("shipmentStatus"));
                v.add(new Vector());
                i++;
            } 
            return v;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
   }
   public void CreateShipment()
   {
       Container container = new Container(containerID);
       container.UpdateContainerStatus("Booked");
       IdGenerator();
       String query = "insert into Shipment Values ('"+ShipmentId+"','"+containerID+"','"+CustomerID+"','"+cosigneeName+"','"+cosigneeMobile+"','"+Destination+"','"+cosingneeAddress+"','"+Deptdate+"','Pending')";
       con.Operation(query);
   }
   
   public void PassProducts()
   {
        for (Product product1 : product) {
            product1.AddProducts(ShipmentId);
        }
   }
  
   private void IdGenerator()
    {
              con.Select("SELECT  COUNT(shipmentID)+1 as ID FROM Shipment");
         try {  
            if(con.rs.next())
            {
                ShipmentId = "ship-00"+con.rs.getString("ID");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public String GetShipmentId()
    {
        return ShipmentId;
    }
    
    public String GetShipmentDate()
    {
        Date date = new Date();
        Calendar c = Calendar.getInstance(); 
        c.setTime(date);
        c.add(Calendar.DATE, 7);
        date = c.getTime();
         SimpleDateFormat Format = new SimpleDateFormat("dd/MM/yyy");
         return Format.format(date);
    }
    public void UpdateShipmentStatus(String Status)
    {
       String query = "update Shipment set shipmentStatus = '"+Status+"' where shipmentID = '"+ShipmentId+"'"; 
        con.Operation(query);
        try {
            if (con.rs.next()) {
            }
            //return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        } 
    }
}
